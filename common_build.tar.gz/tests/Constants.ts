export const TEST_ARGS_STR: string = 'Argument validity checking';
export const TEST_CLASS_STR: string = 'Class tests';
